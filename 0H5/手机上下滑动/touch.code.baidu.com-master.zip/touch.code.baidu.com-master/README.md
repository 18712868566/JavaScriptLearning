touchjs official site
=======

for more information, please visit http://code.baidu.com.
